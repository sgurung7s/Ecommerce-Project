const mongoose = require('mongoose');

const ProductSchema = mongoose.Schema({
    product_name:{
        type: String,
        required: true
    },
    price: {
        type: String,
        required: true
    },
    manufacturer: {
        type: String,
        requried: true
    }
});

const Product = module.exports =  mongoose.model('Product', ProductSchema);