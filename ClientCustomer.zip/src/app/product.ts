export class Product{
    _id?: string;
    product_name?: string;
    price?: string;
    manufacturer?: string;
}