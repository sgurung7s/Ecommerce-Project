import {OnInit, Component, TemplateRef} from '@angular/core';
import {ProductService} from '../product.service';
import {Product} from '../product';
import {BsModalRef, BsModalService} from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  providers: [ProductService]
})
export class ProductComponent implements OnInit {
  // private modalService: BsModalService;
  modalRef: BsModalRef;
  products?: Product[];
  product?: Product;
  product_name?: string;
  price?: string;
  manufacturer?: string;

  constructor(private productService: ProductService, private modalService: BsModalService) { }

  ngOnInit(): void {
    this.productService.getProducts()
    .subscribe(products =>
      this.products = products);
  }

  addProduct(){
    const newProduct = {
      product_name: this.product_name,
      price: this.price,
      manufacturer: this.manufacturer
    }

    this.productService.addProduct(newProduct)
      .subscribe(product => {
        this.products?.push(product);
        this.productService.getProducts()
        .subscribe(products =>
          this.products = products);
      });


  }
  getProduct(id: string){
      this.productService.getProducts();
  }

  deleteProduct(id: any){
    var products = this.products;
      this.productService.deleteProduct(id)
      .subscribe(data => {
        if(data.n == 1){
          for(var i = 0; i < products!.length ; i++){
              if(products![i]._id == id){
                this.products!.splice(i,1);
              }
          }
        }
    this.productService.getProducts()
    .subscribe(products =>
      this.products = products);
      })
  }

  updateProduct(id:any){
    this.productService.updateProduct(id, this.product)      
    .subscribe(product => {
      this.productService.getProducts()
      .subscribe(products =>
        this.products = products);
    });
  }


  openModal(template: TemplateRef<any>){
    this.modalRef = this.modalService.show(template, {class: 'modal-dialog-centered', keyboard: false});
  }

}
