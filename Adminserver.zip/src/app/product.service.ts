import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Product} from './product';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http: HttpClient) { }

  getProducts(){
    return this.http.get('http://localhost:5000/api/products')
    .pipe(map((res: any) => res));
  }

  addProduct(newProduct: Product){
    var headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return this.http.post('http://localhost:5000/api/addProduct', newProduct, {headers: headers})
    .pipe(map((res: any) => res));
  }

  deleteProduct(id: any){
    return this.http.delete('http://localhost:5000/api/deleteProduct/'+id)
    .pipe(map((res: any) => res));
  }

  updateProduct(id:any,updatedProduct: Product){
    var headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    return this.http.put('http://localhost:5000/api/updateProduct/'+id, updatedProduct, {headers: headers})
    .pipe(map((res: any) => res));
  }
  
}
