const express = require('express');
const router = express.Router();

const Product = require('../models/products');


// retrieve product data
router.get('/products', (req, res, next)=>{
    Product.find(function(err, products){
        res.json(products);
    });
});


// save (add) product data
router.post('/addProduct', (req, res, next)=>{
    let newProduct = new Product({
        product_name: req.body.product_name,
        price: req.body.price,
        manufacturer: req.body.manufacturer
    });

    newProduct.save((err, product)=>{
        if(err){
            res.json({msg: 'Failed  to add product...'});
        } else {
            res.json({msg: 'Successfully added product'})
        }
    });
});

// delete product data
router.delete('/deleteProduct/:id', (req, res, next)=>{
    Product.remove({_id: req.params.id}, function(err, result){
        if(err){
            res.json(err)
        } else{
            res.json(result);
        }
    });
});

// update product data
router.post('/update-product', (req, res, next)=>{
    Product.remove({_id: req.params.id}, function(err, result){
        if(err){
            res.json(err)
        } else{
            let newProduct = new Product({
                product_name: req.body.product_name,
                price: req.body.price,
                manufacturer: req.body.manufacturer
            });
        
            newProduct.save((err, product)=>{
                if(err){
                    res.json({msg: 'Failed  to update product...'});
                } else {
                    res.json({msg: 'Successfully updated product'})
                }
            });
        }
    });
});

module.exports = router;